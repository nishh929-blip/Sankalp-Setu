import React, { useState } from 'react';
import { useEcosystem } from '../../context/EcosystemContext';
import { X, Mic, Camera, MapPin, CheckCircle2, Sparkles, Send } from 'lucide-react';

export const NewIssueModal = ({ isOpen, onClose }) => {
  const { addNewIssue } = useEcosystem();
  const [isRecording, setIsRecording] = useState(false);
  const [voiceText, setVoiceText] = useState('');
  const [formData, setFormData] = useState({
    title: '',
    category: 'जल आपूर्ति',
    location: 'जयपुर नगर निगम क्षेत्र',
    priority: 'उच्च',
    description: '',
    citizenName: '',
    citizenPhone: ''
  });
  const [aiAnalyzing, setAiAnalyzing] = useState(false);
  const [submittedIssue, setSubmittedIssue] = useState(null);

  if (!isOpen) return null;

  const handleVoiceToggle = () => {
    if (!isRecording) {
      setIsRecording(true);
      setVoiceText('आपकी आवाज़ रिकॉर्ड की जा रही है... (बोलना जारी रखें)');
      setTimeout(() => {
        setIsRecording(false);
        const speechResult = 'हमारे क्षेत्र में मुख्य पेयजल पाइपलाइन टूट गई है और पीने का पानी दूषित आ रहा है।';
        setVoiceText(speechResult);
        setFormData(prev => ({ ...prev, description: speechResult, title: 'पेयजल पाइपलाइन रिसाव व दूषित आपूर्ति' }));
      }, 2500);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setAiAnalyzing(true);

    setTimeout(() => {
      const issue = addNewIssue(formData);
      setAiAnalyzing(false);
      setSubmittedIssue(issue);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto font-sans">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-300 max-w-xl w-full overflow-hidden animate-in fade-in zoom-in-95">
        
        {/* Modal Header */}
        <div className="bg-gov-navy text-white px-6 py-4 flex items-center justify-between border-b-4 border-amber-500">
          <div>
            <div className="flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <h3 className="text-lg font-bold">नई जन समस्या दर्ज करें (Report Issue)</h3>
            </div>
            <p className="text-xs text-slate-300">आपकी समस्या AI द्वारा विश्लेषित होकर तुरंत सही विभाग को प्रेषित होगी</p>
          </div>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {!submittedIssue ? (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
            
            {/* Quick Access Voice Assistant CTA */}
            <div className="bg-amber-50 rounded-lg p-3.5 border border-amber-200 flex items-center justify-between">
              <div>
                <span className="font-bold text-amber-900 block text-xs">🎤 समस्या बोलकर दर्ज करें (Voice Input)</span>
                <span className="text-[11px] text-amber-800">बोलने के लिए माइक बटन दबाएं, AI स्वतः टाइप करेगा</span>
              </div>
              <button
                type="button"
                onClick={handleVoiceToggle}
                className={`px-3 py-2 rounded-lg font-bold flex items-center gap-1.5 transition-colors ${
                  isRecording 
                    ? 'bg-red-600 text-white animate-pulse' 
                    : 'bg-amber-500 hover:bg-amber-600 text-gov-navy'
                }`}
              >
                <Mic className="w-4 h-4" />
                <span>{isRecording ? 'रिकॉर्ड जारी...' : 'बोलें'}</span>
              </button>
            </div>

            {voiceText && (
              <div className="bg-emerald-50 text-emerald-900 p-2.5 rounded border border-emerald-200 font-medium">
                🗣️ एआई स्पीच रिकॉग्निशन: "{voiceText}"
              </div>
            )}

            {/* Title */}
            <div>
              <label className="block font-bold text-slate-700 mb-1">समस्या का नाम / शीर्षक *</label>
              <input
                type="text"
                required
                placeholder="उदा. नाले की सफाई / सड़क मरम्मत"
                value={formData.title}
                onChange={e => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-2 focus:ring-gov-navy focus:outline-none text-xs"
              />
            </div>

            {/* Category & Priority */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">श्रेणी (Category) *</label>
                <select
                  value={formData.category}
                  onChange={e => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-2 focus:ring-gov-navy focus:outline-none text-xs bg-white"
                >
                  <option value="जल आपूर्ति">जल आपूर्ति (Water)</option>
                  <option value="सड़क एवं आधारभूत संरचना">सड़क एवं बुनियादी ढांचा (Roads)</option>
                  <option value="कचरा प्रबंधन">कचरा प्रबंधन (Waste)</option>
                  <option value="स्ट्रीट लाइट">स्ट्रीट लाइट (Lights)</option>
                  <option value="स्वास्थ्य">स्वास्थ्य (Health)</option>
                  <option value="बिजली">बिजली (Power)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">प्राथमिकता स्तर</label>
                <select
                  value={formData.priority}
                  onChange={e => setFormData({ ...formData, priority: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-2 focus:ring-gov-navy focus:outline-none text-xs bg-white"
                >
                  <option value="उच्च">🔴 उच्च (Emergency / High)</option>
                  <option value="मध्यम">🟠 मध्यम (Normal)</option>
                  <option value="निम्न">🟢 निम्न (Low Priority)</option>
                </select>
              </div>
            </div>

            {/* Location & Details */}
            <div>
              <label className="block font-bold text-slate-700 mb-1">स्थान / वार्ड / लैंडमार्क *</label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="उदा. वार्ड 26, वैशाली नगर, जयपुर"
                  value={formData.location}
                  onChange={e => setFormData({ ...formData, location: e.target.value })}
                  className="w-full px-3 py-2 pl-8 border border-slate-300 rounded focus:ring-2 focus:ring-gov-navy focus:outline-none text-xs"
                />
                <MapPin className="w-4 h-4 text-red-600 absolute left-2.5 top-2.5" />
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block font-bold text-slate-700 mb-1">समस्या का पूरा विवरण</label>
              <textarea
                rows={3}
                placeholder="कृपया समस्या का विस्तृत विवरण लिखें..."
                value={formData.description}
                onChange={e => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-2 focus:ring-gov-navy focus:outline-none text-xs"
              ></textarea>
            </div>

            {/* Attachment preview */}
            <div className="border-2 border-dashed border-slate-300 rounded-lg p-3 text-center bg-slate-50">
              <Camera className="w-6 h-6 text-slate-400 mx-auto mb-1" />
              <span className="text-slate-600 font-medium block">📷 फोटो या वीडियो अपलोड करें (Optional)</span>
              <span className="text-[10px] text-slate-400">JPG, PNG (Max 5MB)</span>
            </div>

            {/* Submit Button */}
            <div className="pt-2 flex justify-end space-x-2 border-t border-slate-200">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded"
              >
                रद्द करें
              </button>
              <button
                type="submit"
                disabled={aiAnalyzing}
                className="px-6 py-2 bg-gov-navy hover:bg-slate-800 text-white font-bold rounded flex items-center gap-1.5 shadow"
              >
                {aiAnalyzing ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    <span>AI विश्लेषण जारी...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 text-amber-400" />
                    <span>समस्या दर्ज करें & AI स्मार्ट रूट करें</span>
                  </>
                )}
              </button>
            </div>
          </form>
        ) : (
          /* Submission Success State */
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <h3 className="text-lg font-bold text-gov-navy">समस्या सफलतापूर्वक दर्ज हो गई है!</h3>
              <p className="text-xs text-slate-600 mt-1">आपकी शिकायत आईडी: <span className="font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded border">{submittedIssue.id}</span></p>
            </div>

            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 text-left text-xs space-y-2">
              <div className="font-bold text-slate-800 border-b border-slate-200 pb-1 flex items-center gap-1">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>AI स्मार्ट रूटिंग परिणाम (Live AI Routing):</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">श्रेणी:</span>
                <span className="font-semibold text-slate-800">{submittedIssue.category}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">आवंटित विभाग:</span>
                <span className="font-semibold text-emerald-700">{submittedIssue.assignedDept}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">AI सार्थकता स्कोर:</span>
                <span className="font-bold text-blue-700">{submittedIssue.aiConfidence}%</span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full bg-gov-navy hover:bg-slate-800 text-white font-bold py-2.5 rounded shadow text-xs"
            >
              डैशबोर्ड पर वापस जाएं
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
